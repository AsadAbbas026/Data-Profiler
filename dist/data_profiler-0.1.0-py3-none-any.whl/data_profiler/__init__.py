# data_profiler/__init__.py

from .profiler import DataProfiler  # Import the main class

__all__ = ['DataProfiler']  # Explicitly define what gets imported with *
