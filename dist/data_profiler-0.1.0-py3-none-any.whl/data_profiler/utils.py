# data_profiler/utils.py

def format_percent(val):
    """Format a float as a percentage string."""
    return f"{val * 100:.2f}%"
